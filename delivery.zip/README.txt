SETUP INSTRUCTIONS:

These setup instructions are for Linux VPS.

+   Install latest version of python.
+   Install pip latest version.
+   Install required modules using from requirements.txt file using "pip install -r requirements.txt".
+   Install mongodb for your linux version.
+   Rename the sample-config.json file to config.json and open it.
+   Follow this link --> (https://core.telegram.org/api/obtaining_api_id#obtaining-api-id) to get you api_id and hash for telegram.
+   Follow this link --> () to create a bot and get the token.
+   Add api_id, hash, phone number and bot token in config.json file.
+   Add the bot to your group/channel and make it admin.
+   Enter your group link in config.json.
+   Enter your instagram username and password and in config.json.
+   Do a post on your instagram account and get it's link and put it in config.json, 
    this post will be used for users verification.
+   Enter your telegram username as the admin username and you are done.
+   Run the mongodb before running the bot.
+   Run the bot from main.py file.
+   Let me know of any problems.
+   Thank you!